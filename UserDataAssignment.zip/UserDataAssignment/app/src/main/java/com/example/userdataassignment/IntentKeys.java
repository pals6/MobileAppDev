package com.example.userdataassignment;

public class IntentKeys {
    public static final String USER_KEY = "USER";
    public static final String DATE = "DATE";
}
