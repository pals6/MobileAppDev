package com.assignment.assignment04;

public class IntentKeys {
    public static final String USER_KEY = "USER";
    //public static final String PROFILE_KEY = "PROFILE";
}
